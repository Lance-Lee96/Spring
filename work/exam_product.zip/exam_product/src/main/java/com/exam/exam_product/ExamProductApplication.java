package com.exam.exam_product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamProductApplication.class, args);
	}

}
