package com.exam.exam_product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
