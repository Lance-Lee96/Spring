package com.example.demo.qualifier;

public interface Computer1 {
	//스크린의 가로길이를 반환하는 메서드
	public int getScreenWidth();
}
